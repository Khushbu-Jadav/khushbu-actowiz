import re

a="Khushbu Jadav"
b="khushbujadavactowiz@gmail.com"


#search method gives the index of pattern's first occurence
match=re.search(r".",b) # . gives any char
match2=re.search(r"\.",b) # (escape)\. gives actual .
match3=re.search(r"[@]",b)
match4=re.findall(r"[a]",b) # Match any one character from a set
# findall Return ALL matches
match5=re.findall(r"[abc]",b)

print(match)
print(match2)
print(match3)
print(match4)
print(match5)

text="cat cot cut"
print(re.findall("c[ao]t", text))

text2="a b c d e x y z"
print(re.findall("[a-d]",text2)) #A set of characters

#special shortcuts
# \d : digit
# \d+ : multiple digits in one ele
# \w : word char
# \s : space

text3="the number is 5026"
print(re.findall(r"\d",text3))

print(re.findall(r"\d+",text3))

print(re.findall(r"\w",text3))

print(re.findall(r"\s",text3))

text4 = "aaa a aa"
print(re.findall("a", text4))
print(re.findall("a+", text4))

text5 = "aa ab a"
print(re.findall("a*", text5))


# string to see if it starts with "The" and ends with "Spain":
txt = "The rain in Spain 25"
x = re.search("^The.*Spain$", txt)

if x:
  print("YES! We have a match!")
else:
  print("No match")

print(re.findall(r"[a-n]", txt)) #A set of characters
print(re.findall(r"\d", txt)) #Signals a special sequence (can also be used to escape special characters)
print(re.findall(r"he..o", "hello world")) #Any character (except newline character)
print(re.findall(r"^T",txt))
#Split the string at every white-space character
y=re.split(r"\s",txt)
print(y)
print(re.split(r"\s",txt,1))

#Replace all white-space characters with the digit "4"
z = re.sub(r"\s", "4", txt)
print(z)